import React from "react";

const BaseUrl = () => {
  return "https://dtou.herokuapp.com";
};

export default BaseUrl;
